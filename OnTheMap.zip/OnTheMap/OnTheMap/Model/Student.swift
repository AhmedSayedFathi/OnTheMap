//
//  Student.swift
//  OnTheMap
//
//  Created by Ahmed Sayed Fathi on 7/14/19.
//  Copyright © 2019 Ahmed Sayed Fathi. All rights reserved.
//

import Foundation

struct Students: Codable {
    let results: [Student]?
}

struct Student : Codable {
    var uniqueKey: String
    var objectId: String
    var firstName: String
    var lastName: String
    var longitude: Double
    var latitude: Double
    var mediaURL: String
}
